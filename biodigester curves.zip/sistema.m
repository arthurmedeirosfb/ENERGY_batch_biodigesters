%function retval = sistema(t,Y);

source('param.m');
options=odeset('RelTol',1e-6);
Tspan=[1:1:14];
S10=60;    %condição inicial
S20=29;
X10=1;
X20=1;
IC = [S10;S20;X10;X20];
[t Y] = ode45(@(t,Y) funsyst(t,Y),Tspan,IC); % Solve ODE

%endfunction
