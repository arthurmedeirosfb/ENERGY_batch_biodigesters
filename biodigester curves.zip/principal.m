%%%Principal
clear all;
clc;
%source('param.m');
sistema
mi1 = mimax./(1 + ksvb./Y(:,1) + Y(:,2)./kia);
 mi2 = mimax./(1 + kagv./Y(:,2) + Y(:,2)./kim);
 V = 0.5 * mi2 .* Y(:,4) * (1 - Y2)/Y2
 sum(V)
 plot(t,V)
%plotar o resultados

