function Fv=funsyst(t,Y);

source('param.m');
       %OK y(1) = x and y(2) = y
       %OK fv3 e fv4 tambem, são 4 EDOs
       %calcular volume
       %OK plotar?
       mi1 = mimax./(1 + ksvb./Y(1,:) + Y(2,:)./kia);
       mi2 = mimax./(1 + kagv./Y(2,:) + Y(2,:)./kim);

       Fv(1,:)= (-Y(1,:)./t) - (mi1 * (Y(3,:))./Y1);

       Fv(2,:)= (Y(1) - Y(2,:))./t - (mi2 * Y(4,:))./Y2 + (mi1.*Y(3,:).*(1-Y1))./Y1;

       Fv(3,:)= (mi1 - k1 - (1/t)).* Y(3,:);

       Fv(4,:)= (mi2 - k2 - (1/t)).* Y(4,:);

    end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

