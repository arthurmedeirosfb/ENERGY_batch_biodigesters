%parametros
Y1 = 0.1;
Y2 = 0.005;


mimax = 0.30;

kim = 6;
kia = 12;
kagv = 2;
ksvb = 9;
k1 = 0.1 * mimax;
k2 = 0.1 * mimax;

t = 14;
